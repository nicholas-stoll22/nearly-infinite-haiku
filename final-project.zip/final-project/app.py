from asyncio.log import logger
import pdb
from flask import Flask, render_template
from data import *
from logic import *

app = Flask(__name__)

@app.route('/')
def index():

    return render_template('index.html',
    line_1 = first_line(),
    line_2 = second_line(),
    line_3 = third_line())

@app.route('/project')
def project():
    return render_template('project.html')

@app.route('/info')
def info():
    return render_template('info.html',
    author_1 = first_line_author(),
    title_1 = title_1(),
    author_2 = second_line_author(),
    title_2 = title_2(),
    author_3 = third_line_author(),
    title_3 = title_3())

@app.errorhandler(500)
def internal_error(error):
    return "500 error"

@app.errorhandler(404)
def not_found(error):
    return "404 error",404

if __name__ == "__main__":
    app.run(debug=True)