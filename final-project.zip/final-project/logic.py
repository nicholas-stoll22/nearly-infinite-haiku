from data import *
from random import *

global line
global line_two
global line_three

def first_line():
    global line
    line = randint(0, len(line_1) - 1)
    return(line_1[line][2])

def first_line_author():
    return(line_1[line][0])

def title_1():
    return(line_1[line][1])

def second_line():
    global line_two
    line_two = randint(0, len(line_2) - 1)
    return(line_2[line_two][2])

def second_line_author():
    return(line_2[line_two][0])

def title_2():
    return(line_2[line_two][1])

def third_line():
    global line_three
    line_three = randint(0, len(line_3) - 1)
    return(line_3[line_three][2])

def third_line_author():
    return(line_3[line_three][0])

def title_3():
    return(line_3[line_three][1])