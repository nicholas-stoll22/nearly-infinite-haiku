line_1 = {
    0: ["Kobayashi Issa", "A World of Dew","A world of dew,"],
    1: ["Matsuo Bashō", "The Old Pond","An old silent pond"],
    2: ["Yosa Buson", "Lighting One Candle","The light of a candle"],
    3: ["Katsushika Hukusai", "A Poppy Blooms","I write, erase, rewrite"],
    4: ["Jack Kerouac", "The Taste of Rain","The taste"],
    5: ["Sonia Sanchez", "Haiku [for you]","love between us is"],
    6: ["Ravi Shankar", "Lines on a Skull","life's little, our heads"],
    7: ["Joyce Clement", "Birds Punctuate the Days","Period"],
    8: ["Suh Joon Kim", "The Pink Summer Sphere","The chill, warming in"],
    9: ["Paul Holmes", "A Caress","Strokes of affection"],
}

line_2 = {
    0: ["Kobayashi Issa", "A World of Dew","And within every dewdrop"],
    1: ["Matsuo Bashō", "The Old Pond","A frog jumps into the pond--"],
    2: ["Yosa Buson", "Lighting One Candle","Is transferred to another candle--"],
    3: ["Katsushika Hukusai", "A Poppy Blooms","Erase again, and then"],
    4: ["Jack Kerouac", "The Taste of Rain","Of rain"],
    5: ["Sonia Sanchez", "Haiku [for you]," "speech and breath. loving you is"],
    6: ["Ravi Shankar", "Lines on a Skull","sad. Redeemed and wasting clay"],
    7: ["Joyce Clement", "Birds Punctuate the Days","One blue egg all suummer long"],
    8: ["Suh Joon Kim", "The Pink Summer Sphere","Shock, pleasure, bursting within"],
    9: ["Paul Holmes", "A Caress","Light and tenderly expressed"],
}

line_3 = {
    0: ["Kobayashi Issa", "A World of Dew","A world of struggle."],
    1: ["Matsuo Bashō", "The Old Pond","Splash! Silence again."],
    2: ["Yosa Buson", "Lighting One Candle","Spring twilight"],
    3: ["Katsushika Hukusai", "A Poppy Blooms","A poppy blooms."],
    4: ["Jack Kerouac", "The Taste of Rain","--Why kneel?"],
    5: ["Sonia Sanchez", "Haiku [for you]","a long river running."],
    6: ["Ravi Shankar", "Lines on a Skull","this chance. Be of use."],
    7: ["Joyce Clement", "Birds Punctuate the Days","Now gone"],
    8: ["Suh Joon Kim", "The Pink Summer Sphere","Summer tongue awakes"],
    9: ["Paul Holmes", "A Caress","Keep love's bonds so strong."],
}