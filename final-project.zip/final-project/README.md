#nearly-infinite-haiku
